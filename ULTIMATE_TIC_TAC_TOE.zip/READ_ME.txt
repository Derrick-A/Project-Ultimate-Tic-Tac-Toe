Run File on Main.java
Make Sure it is rn on eclipse