package Swingg;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
	TicTacTest XnO = new TicTacTest();
	
	
		
	}}
		
		
	
//		JFrame frameObj = new JFrame();
//		frameObj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frameObj.setSize(500, 500);
//		frameObj.setLayout(new GridLayout(9, 9, 3, 5));
//		
//		JButton btn1 = new JButton("1");    
//		JButton btn2 = new JButton("2");    
//		JButton btn3 = new JButton("3");    
//		JButton btn4 = new JButton("4");    
//		JButton btn5 = new JButton("5");    
//		JButton btn6 = new JButton("6");    
//		JButton btn7 = new JButton("7");    
//		JButton btn8 = new JButton("8");    
//		JButton btn9 = new JButton("9"); 
//		JButton btn10 = new JButton("10");    
//		JButton btn11 = new JButton("11");    
//		JButton btn12 = new JButton("12");    
//		JButton btn13 = new JButton("13");    
//		JButton btn14 = new JButton("14");    
//		JButton btn15 = new JButton("15");    
//		JButton btn16 = new JButton("16");    
//		JButton btn17 = new JButton("17");    
//		JButton btn18 = new JButton("18");
//		JButton btn19 = new JButton("19");    
//		JButton btn20 = new JButton("20");    
//		JButton btn21 = new JButton("21");    
//		JButton btn22 = new JButton("22");    
//		JButton btn23 = new JButton("23");    
//		JButton btn24 = new JButton("24");    
//		JButton btn25 = new JButton("25");    
//		JButton btn26 = new JButton("26");    
//		JButton btn27 = new JButton("27"); 
//		JButton btn28 = new JButton("28");    
//		JButton btn29 = new JButton("29");    
//		JButton btn30 = new JButton("30");    
//		JButton btn31 = new JButton("31");    
//		JButton btn32 = new JButton("32");    
//		JButton btn33 = new JButton("33");    
//		JButton btn34 = new JButton("34");    
//		JButton btn35 = new JButton("35");    
//		JButton btn36 = new JButton("36");
//		JButton btn37 = new JButton("37");    
//		JButton btn38 = new JButton("38");    
//		JButton btn39 = new JButton("39");    
//		JButton btn40 = new JButton("40");    
//		JButton btn41 = new JButton("41");    
//		JButton btn42 = new JButton("42");    
//		JButton btn43 = new JButton("43");    
//		JButton btn44 = new JButton("44");    
//		JButton btn45 = new JButton("45");
//		JButton btn46 = new JButton("46");    
//		JButton btn47 = new JButton("47");    
//		JButton btn48 = new JButton("48");    
//		JButton btn49 = new JButton("49");    
//		JButton btn50 = new JButton("50");    
//		JButton btn51 = new JButton("51");    
//		JButton btn52 = new JButton("52");    
//		JButton btn53 = new JButton("53");    
//		JButton btn54 = new JButton("54");
//		JButton btn55 = new JButton("55");    
//		JButton btn56 = new JButton("56");    
//		JButton btn57 = new JButton("57");    
//		JButton btn58 = new JButton("58");    
//		JButton btn59 = new JButton("59");    
//		JButton btn60 = new JButton("60");    
//		JButton btn61 = new JButton("61");    
//		JButton btn62 = new JButton("62");    
//		JButton btn63 = new JButton("63");
//		JButton btn64 = new JButton("64");    
//		JButton btn65 = new JButton("65");    
//		JButton btn66 = new JButton("66");    
//		JButton btn67 = new JButton("67");    
//		JButton btn68 = new JButton("68");    
//		JButton btn69 = new JButton("69");    
//		JButton btn70 = new JButton("70");    
//		JButton btn71 = new JButton("71");    
//		JButton btn72 = new JButton("72"); 
//		JButton btn73 = new JButton("73");    
//		JButton btn74 = new JButton("74");    
//		JButton btn75 = new JButton("75");    
//		JButton btn76 = new JButton("76");    
//		JButton btn77 = new JButton("77");    
//		JButton btn78 = new JButton("78");    
//		JButton btn79 = new JButton("79");    
//		JButton btn80 = new JButton("80");    
//		JButton btn81 = new JButton("81");
//		
//		frameObj.add(btn1); frameObj.add(btn2); frameObj.add(btn3);frameObj.add(btn4);frameObj.add(btn5);frameObj.add(btn6);frameObj.add(btn7);frameObj.add(btn8);frameObj.add(btn9);
//		frameObj.add(btn10); frameObj.add(btn11); frameObj.add(btn12);frameObj.add(btn13);frameObj.add(btn14);frameObj.add(btn15);frameObj.add(btn16);frameObj.add(btn17);frameObj.add(btn18);
//		frameObj.add(btn19); frameObj.add(btn20); frameObj.add(btn21);frameObj.add(btn22);frameObj.add(btn23);frameObj.add(btn24);frameObj.add(btn25);frameObj.add(btn26);frameObj.add(btn27);
//		frameObj.add(btn28); frameObj.add(btn29); frameObj.add(btn30);frameObj.add(btn31);frameObj.add(btn32);frameObj.add(btn33);frameObj.add(btn34);frameObj.add(btn35);frameObj.add(btn36);
//		frameObj.add(btn37); frameObj.add(btn38); frameObj.add(btn39);frameObj.add(btn40);frameObj.add(btn41);frameObj.add(btn42);frameObj.add(btn43);frameObj.add(btn44);frameObj.add(btn45);
//		frameObj.add(btn46); frameObj.add(btn47); frameObj.add(btn48);frameObj.add(btn49);frameObj.add(btn50);frameObj.add(btn51);frameObj.add(btn52);frameObj.add(btn53);frameObj.add(btn54);
//		frameObj.add(btn55); frameObj.add(btn56); frameObj.add(btn57);frameObj.add(btn58);frameObj.add(btn59);frameObj.add(btn60);frameObj.add(btn61);frameObj.add(btn62);frameObj.add(btn63);
//		frameObj.add(btn64); frameObj.add(btn65); frameObj.add(btn66);frameObj.add(btn67);frameObj.add(btn68);frameObj.add(btn69);frameObj.add(btn70);frameObj.add(btn71);frameObj.add(btn72);
//		frameObj.add(btn73); frameObj.add(btn74); frameObj.add(btn75);frameObj.add(btn76);frameObj.add(btn77);frameObj.add(btn78);frameObj.add(btn79);frameObj.add(btn80);frameObj.add(btn81);
//		
//		frameObj.setVisible(true);
//	}
//}
